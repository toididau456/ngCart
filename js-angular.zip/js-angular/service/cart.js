app.service('ngCart', [function() {
    /*	var obj = {};
    	obj.init = function(arg1) {
    		alert('this is sidebar ' + arg1);
    	}
    	obj.init();
    	return obj;*/
    this.init = function() {
        this.$cart = {
            items: []
        };
    };

    this.init();

    this.addItem = function(id, name, price, quantity) {
        var items = this.$cart.items;
        if (this.$cart.items.length == 0) {
            this.$cart.items[id] = { name, price, quantity };
        } else {
        	items.forEach(function(element, index) {
	            if (index == id) {
	                items[id].quantity += 1;
	            } else {
	            	items[id] = { name, price, quantity };
	            }
       		 });
        }
        this.totalPrice();
    };

    this.totalPrice = function(){
    	let items = this.$cart.items;
    	var total = 0;
    	items.forEach( function(element, index) {
    		total += (element.quantity * parseFloat(element.price));
    	});
    	
    	return total;
    };
}]);