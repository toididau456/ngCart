app.controller('HomeController', ['$scope', 'product', 'ngCart', function ($scope, product, ngCart) {
	product.success(function(data){
		$scope.products = data;
	});
	$scope.ngCart = ngCart;
}]);