app.controller('ProductController', ['$scope', 'ngCart', 'product', '$routeParams', function($scope, ngCart, product, $routeParams) {
    product.success(function(data) {
        $scope.product = data[$routeParams.id];
    });
    $scope.ngCart = ngCart;
}]);